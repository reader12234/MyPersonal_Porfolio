<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="card">
    <h2>Attendance Report</h2>
    
    <form method="get" action="/attendance-report" class="mb-3">
        <div class="form-group">
            <label for="date">Select Date</label>
            <input type="date" id="date" name="date" value="<?= esc($date) ?>" required>
        </div>
        <div class="text-center">
            <button type="submit" class="btn btn-primary">View Report</button>
        </div>
    </form>
</div>

<div class="card">
    <h3>Attendance Records for <?= esc($date) ?></h3>
    
    <?php if (!empty($records)): ?>
        <!-- Summary Section -->
        <div class="mb-3" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem;">
            <div style="text-align: center; padding: 1rem; background: var(--secondary-color); border-radius: 4px;">
                <h4>Total Students</h4>
                <p style="font-size: 1.5rem; color: var(--primary-color);"><?= count($records) ?></p>
            </div>
            <div style="text-align: center; padding: 1rem; background: var(--success-color); border-radius: 4px; color: white;">
                <h4>Present</h4>
                <p style="font-size: 1.5rem;">
                    <?= count(array_filter($records, fn($r) => $r['status'] === 'PRESENT')) ?>
                </p>
            </div>
            <div style="text-align: center; padding: 1rem; background: var(--danger-color); border-radius: 4px; color: white;">
                <h4>Absent</h4>
                <p style="font-size: 1.5rem;">
                    <?= count(array_filter($records, fn($r) => $r['status'] === 'ABSENT')) ?>
                </p>
            </div>
        </div>

        <div style="overflow-x: auto;">
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Course</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($records as $i => $r): ?>
                        <tr>
                            <td><?= $i + 1 ?></td>
                            <td><?= esc($r['s_lastname']) ?>, <?= esc($r['s_firstname']) ?></td>
                            <td><?= esc($r['course']) ?></td>
                            <td style="text-align: center;">
                                <span class="<?= $r['status'] === 'PRESENT' ? 'text-success' : 'text-danger' ?>"
                                      style="font-weight: bold;">
                                    <?= esc($r['status']) ?>
                                </span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <p class="text-center">No attendance records found for this date.</p>
    <?php endif; ?>
</div>
<?= $this->endSection() ?>