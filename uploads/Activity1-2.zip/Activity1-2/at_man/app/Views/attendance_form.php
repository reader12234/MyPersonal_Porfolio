<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="card">
    <h2>Take Attendance</h2>
    
    <form method="get" action="/attendance-form" class="mb-3">
        <div class="form-group">
            <label for="date">Select Date</label>
            <input type="date" id="date" name="date" value="<?= esc($date) ?>" required>
        </div>
        <div class="text-center">
            <button type="submit" class="btn btn-primary">Load Attendance Sheet</button>
        </div>
    </form>
</div>

<div class="card">
    <h3>Attendance Sheet for <?= esc($date) ?></h3>
    
    <form method="post" action="/submit-attendance">
        <?= csrf_field() ?>
        <input type="hidden" name="attendance_date" value="<?= esc($date) ?>">
        
        <div style="overflow-x: auto;">
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Course</th>
                        <th style="text-align: center">Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $map = [];
                    if (!empty($records)) {
                        foreach ($records as $r) {
                            $map[$r['student_id']] = $r['status'];
                        }
                    }
                    if (!empty($students)):
                        foreach ($students as $i => $s):
                            $sid = $s['student_id'];
                            $status = $map[$sid] ?? '';
                    ?>
                        <tr>
                            <td><?= $i + 1 ?></td>
                            <td><?= esc($s['s_lastname']) ?>, <?= esc($s['s_firstname']) ?></td>
                            <td><?= esc($s['course']) ?></td>
                            <td style="text-align: center">
                                <div style="display: inline-flex; gap: 1rem;">
                                    <label style="display: inline-flex; align-items: center; gap: 0.25rem">
                                        <input type="radio" name="status[<?= $sid ?>]" value="PRESENT" 
                                               <?= $status === 'PRESENT' ? 'checked' : '' ?> required>
                                        Present
                                    </label>
                                    <label style="display: inline-flex; align-items: center; gap: 0.25rem">
                                        <input type="radio" name="status[<?= $sid ?>]" value="ABSENT" 
                                               <?= $status === 'ABSENT' ? 'checked' : '' ?>>
                                        Absent
                                    </label>
                                </div>
                            </td>
                        </tr>
                    <?php 
                        endforeach;
                    else:
                    ?>
                        <tr>
                            <td colspan="4" class="text-center">No students available</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <?php if (!empty($students)): ?>
            <div class="text-center mt-3">
                <button type="submit" class="btn btn-primary">Save Attendance</button>
            </div>
        <?php endif; ?>
    </form>
</div>
<?= $this->endSection() ?>