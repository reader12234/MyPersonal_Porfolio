<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="card">
    <h2 class="text-center">Create Account</h2>

    <form method="post" action="/register/save">
        <div class="form-group">
            <label for="username">Username</label>
            <input type="text" name="username" id="username" value="<?= old('username') ?>" required 
                   placeholder="Choose a username">
        </div>

        <div class="form-group">
            <label for="email">Email Address</label>
            <input type="email" name="email" id="email" value="<?= old('email') ?>" required 
                   placeholder="Enter your email">
        </div>

        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" name="password" id="password" required 
                   placeholder="Choose a password">
        </div>

        <div class="form-group text-center">
            <button type="submit" class="btn btn-primary">Create Account</button>
        </div>
    </form>

    <p class="text-center mt-3">
        Already have an account? <a href="/login">Login here</a>
    </p>
</div>
<?= $this->endSection() ?>
