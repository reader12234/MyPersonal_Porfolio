<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="card">
    <h2>Add New Student</h2>
    
    <form method="post" action="/add-student" class="mb-3">
        <?= csrf_field() ?>
        <div class="form-group">
            <label for="s_lastname">Last Name</label>
            <input type="text" id="s_lastname" name="s_lastname" required placeholder="Enter last name">
        </div>
        <div class="form-group">
            <label for="s_firstname">First Name</label>
            <input type="text" id="s_firstname" name="s_firstname" required placeholder="Enter first name">
        </div>
        <div class="form-group">
            <label for="s_middlename">Middle Name</label>
            <input type="text" id="s_middlename" name="s_middlename" placeholder="Enter middle name">
        </div>
        <div class="form-group">
            <label for="course">Course</label>
            <input type="text" id="course" name="course" required placeholder="Enter course">
        </div>
        <div class="text-center">
            <button type="submit" class="btn btn-primary">Add Student</button>
        </div>
    </form>
</div>

<div class="card">
    <h2>Student List</h2>
    <?php if (!empty($students)): ?>
        <div style="overflow-x: auto;">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Course</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($students as $s): ?>
                        <tr>
                            <td><?= esc($s['student_id']) ?></td>
                            <td><?= esc($s['s_lastname']) ?>, <?= esc($s['s_firstname']) ?> <?= esc($s['s_middlename']) ?></td>
                            <td><?= esc($s['course']) ?></td>
                            <td>
                                <button class="btn btn-danger" style="padding: 0.25rem 0.5rem; font-size: 0.875rem;"
                                        onclick="if(confirm('Are you sure you want to delete this student?')) { /* Add delete functionality */ }">
                                    Delete
                                </button>
                            </td>
                        </tr>
                    <?php endforeach ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <p class="text-center">No students registered yet.</p>
    <?php endif ?>
</div>
<?= $this->endSection() ?>