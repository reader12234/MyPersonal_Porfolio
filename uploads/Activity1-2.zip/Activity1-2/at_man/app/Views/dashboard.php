<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="card">
    <h2>Welcome, <?= esc($username ?? 'User') ?>!</h2>
    
    <div class="user-info mb-3">
        <h3>Your Profile</h3>
        <p><strong>Username:</strong> <?= esc($username ?? 'User') ?></p>
        <p><strong>Email:</strong> <?= esc($email ?? 'Not available') ?></p>
    </div>

    <div class="text-center">
        <a href="/students" class="btn btn-primary">Manage Students</a>
        <a href="/attendance-form" class="btn btn-primary">Take Attendance</a>
        <a href="/attendance-report" class="btn btn-primary">View Reports</a>
    </div>
</div>

<!-- Quick Stats Section -->
<div class="card">
    <h3>Quick Statistics</h3>
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem;">
        <div style="text-align: center; padding: 1rem; background: var(--secondary-color); border-radius: 4px;">
            <h4>Total Students</h4>
            <p style="font-size: 1.5rem; color: var(--primary-color);">0</p>
        </div>
        <div style="text-align: center; padding: 1rem; background: var(--secondary-color); border-radius: 4px;">
            <h4>Today's Attendance</h4>
            <p style="font-size: 1.5rem; color: var(--primary-color);">0</p>
        </div>
        <div style="text-align: center; padding: 1rem; background: var(--secondary-color); border-radius: 4px;">
            <h4>Absent Students</h4>
            <p style="font-size: 1.5rem; color: var(--primary-color);">0</p>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
