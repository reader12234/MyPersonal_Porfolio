<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Attendance System</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            min-height: 100vh;
        }
        .navbar {
            background-color: #0d6efd;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .navbar-brand {
            color: white !important;
            font-weight: bold;
        }
        .card {
            transition: transform 0.2s, box-shadow 0.2s;
            margin: 15px;
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 12px rgba(0,0,0,0.15);
        }
        .card-body {
            padding: 2rem;
        }
        .icon-box {
            font-size: 2.5rem;
            margin-bottom: 1rem;
            color: #0d6efd;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark mb-4">
        <div class="container">
            <a class="navbar-brand" href="#">
                <i class="fas fa-user-graduate me-2"></i>
                Student Attendance System
            </a>
        </div>
    </nav>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-4">
                <a href="students" class="text-decoration-none">
                    <div class="card text-center">
                        <div class="card-body">
                            <div class="icon-box">
                                <i class="fas fa-user-plus"></i>
                            </div>
                            <h4 class="card-title text-dark">Add Student</h4>
                            <p class="card-text text-muted">Register new students in the system</p>
                        </div>
                    </div>
                </a>
            </div>
            
            <div class="col-md-4">
                <a href="attendance-form" class="text-decoration-none">
                    <div class="card text-center">
                        <div class="card-body">
                            <div class="icon-box">
                                <i class="fas fa-clipboard-list"></i>
                            </div>
                            <h4 class="card-title text-dark">Attendance Form</h4>
                            <p class="card-text text-muted">Mark student attendance</p>
                        </div>
                    </div>
                </a>
            </div>
            
            <div class="col-md-4">
                <a href="attendance-report" class="text-decoration-none">
                    <div class="card text-center">
                        <div class="card-body">
                            <div class="icon-box">
                                <i class="fas fa-chart-bar"></i>
                            </div>
                            <h4 class="card-title text-dark">Attendance Report</h4>
                            <p class="card-text text-muted">View attendance statistics</p>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS and Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>