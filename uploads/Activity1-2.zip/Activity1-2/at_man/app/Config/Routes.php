<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

// Authentication Routes
$routes->get('/', 'AuthController::index');
$routes->get('login', 'AuthController::index');  // Add explicit login route
$routes->get('/register', 'AuthController::register');
$routes->post('/register/save', 'AuthController::save');
$routes->post('/login/auth', 'AuthController::auth');
$routes->get('/logout', 'AuthController::logout');
$routes->get('/dashboard', 'AuthController::dashboard', ['filter' => 'auth']);

// Student and Attendance Routes (Protected by auth filter)
$routes->group('', ['filter' => 'auth'], function($routes) {
    $routes->get('students', 'Home::students');
    $routes->post('add-student', 'Home::addStudent');
    $routes->get('attendance-form', 'Home::attendanceForm');
    $routes->post('submit-attendance', 'Home::submitAttendance');
    $routes->get('attendance-report', 'Home::attendanceReport');
});
