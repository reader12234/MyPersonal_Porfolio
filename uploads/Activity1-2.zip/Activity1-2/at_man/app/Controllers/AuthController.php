<?php

namespace App\Controllers;

use App\Models\UserModel;

class AuthController extends BaseController
{
    public function index()
    {
        return view('login', [
            'title' => 'Login - Attendance Management System'
        ]);
    }

    public function register()
    {
        return view('register', [
            'title' => 'Register - Attendance Management System'
        ]);
    }

    public function save()
    {
        log_message('debug', '[Auth/Register] Starting registration process');
        
        $post = $this->request->getPost();
        
        // Log received data (excluding password)
        log_message('debug', '[Auth/Register] Received data: ' . json_encode([
            'username' => $post['username'] ?? 'not set',
            'email' => $post['email'] ?? 'not set',
            'has_password' => isset($post['password'])
        ]));
        
        // Validate required fields
        if (empty($post['username']) || empty($post['email']) || empty($post['password'])) {
            log_message('notice', '[Auth/Register] Missing required fields');
            return redirect()->to('/register')
                ->with('error', 'All fields are required')
                ->withInput();
        }

        // Basic email validation
        if (!filter_var($post['email'], FILTER_VALIDATE_EMAIL)) {
            log_message('notice', '[Auth/Register] Invalid email format: ' . ($post['email'] ?? 'empty'));
            return redirect()->to('/register')
                ->with('error', 'Please enter a valid email address')
                ->withInput();
        }

        try {
            $model = new UserModel();
            
            // Check if email already exists
            if ($model->where('email', $post['email'])->first()) {
                log_message('info', '[Auth/Register] Email already registered: ' . $post['email']);
                return redirect()->to('/register')
                    ->with('error', 'Email address already registered')
                    ->withInput();
            }

            $data = [
                'username' => $post['username'],
                'email'    => $post['email'],
                'password' => password_hash($post['password'], PASSWORD_DEFAULT),
            ];

            log_message('debug', '[Auth/Register] Attempting to insert user');
            
            $result = $model->insert($data);
            
            if ($result === false) {
                $errors = $model->errors();
                log_message('error', '[Auth/Register] Model validation failed: ' . json_encode($errors));
                return redirect()->to('/register')
                    ->with('error', 'Failed to create account: ' . implode(', ', $errors))
                    ->withInput();
            }
            
            log_message('info', '[Auth/Register] User registered successfully: ' . $post['email']);
            return redirect()->to('/')->with('message', 'Registration successful. Please login.');
            
        } catch (\CodeIgniter\Database\Exceptions\DatabaseException $e) {
            log_message('error', '[Auth/Register] Database error: ' . $e->getMessage());
            return redirect()->to('/register')
                ->with('error', 'Database error occurred. Please try again.')
                ->withInput();
                
        } catch (\Exception $e) {
            log_message('error', '[Auth/Register] Unexpected error: ' . $e->getMessage());
            log_message('error', '[Auth/Register] Stack trace: ' . $e->getTraceAsString());
            return redirect()->to('/register')
                ->with('error', 'An unexpected error occurred. Please try again.')
                ->withInput();
        }
    }

    public function auth()
    {
        helper(['form', 'url']);
        $session = session();
        log_message('debug', '[Auth/Login] Starting login process');
        
        try {
            $post = $this->request->getPost();
            
            // Log received data (excluding password)
            log_message('debug', '[Auth/Login] Received data: ' . json_encode([
                'email' => $post['email'] ?? 'not set',
                'has_password' => isset($post['password'])
            ]));

            // Basic validation
            if (empty($post['email']) || empty($post['password'])) {
                log_message('notice', '[Auth/Login] Missing email or password');
                return redirect()->to('/login')
                    ->withInput()
                    ->with('error', 'Both email and password are required');
            }

            $email = $post['email'];
            $password = $post['password'];

            log_message('debug', '[Auth/Login] Attempting login for email: ' . $email);

            $model = new UserModel();
            $user = $model->where('email', $email)->first();
            
            // Log user lookup result (without sensitive data)
            log_message('debug', '[Auth/Login] User lookup result: ' . ($user ? 'found' : 'not found'));

            if (!$user) {
                log_message('notice', '[Auth/Login] No user found with email: ' . $email);
                return redirect()->to('/login')
                    ->withInput()
                    ->with('error', 'No account found with this email address');
            }

            // Log password check attempt (without exposing the actual password)
            log_message('debug', '[Auth/Login] Checking password for user: ' . $email);
            
            if (!isset($user['password'])) {
                log_message('error', '[Auth/Login] User has no password set: ' . $email);
                return redirect()->to('/login')
                    ->withInput()
                    ->with('error', 'Account configuration error. Please contact support.');
            }

            $passwordValid = password_verify($password, $user['password']);
            log_message('debug', '[Auth/Login] Password verification result: ' . ($passwordValid ? 'valid' : 'invalid'));

            if (!$passwordValid) {
                log_message('notice', '[Auth/Login] Invalid password for user: ' . $email);
                return redirect()->to('/login')
                    ->withInput()
                    ->with('error', 'Invalid email or password');
            }

            // Set session data
            $sessionData = [
                'isLoggedIn' => true,
                'user' => [
                    'id' => $user['id'],
                    'username' => $user['username'] ?? $user['email'],
                    'email' => $user['email']
                ]
            ];

            try {
                // Initialize session data
                $session->set($sessionData);
                log_message('info', '[Auth/Login] User logged in successfully: ' . $email);
                
                // Verify session was set
                if ($session->get('isLoggedIn')) {
                    log_message('debug', '[Auth/Login] Session verified for user: ' . $email);
                    return redirect()->to('/dashboard')
                        ->with('message', 'Welcome back, ' . ($user['username'] ?? $email) . '!');
                } else {
                    log_message('error', '[Auth/Login] Session verification failed for user: ' . $email);
                    throw new \Exception('Session verification failed');
                }
            } catch (\Exception $e) {
                log_message('error', '[Auth/Login] Session error: ' . $e->getMessage());
                return redirect()->to('/login')
                    ->with('error', 'Could not create login session. Please try again.');
            }

        } catch (\Exception $e) {
            log_message('error', '[Auth/Login] Error during login: ' . $e->getMessage());
            log_message('error', '[Auth/Login] Stack trace: ' . $e->getTraceAsString());
            
            return redirect()->to('/login')
                ->withInput()
                ->with('error', 'An error occurred during login. Please try again.');
        }
    }

    public function logout()
    {
        $this->session->destroy();
        return redirect()->to('/');
    }

    public function dashboard()
    {
        try {
            // Check if user is logged in
            if (!$this->session->get('isLoggedIn')) {
                return redirect()->to('login')
                    ->with('error', 'Please login first');
            }

            // Get user data from session safely
            $userData = $this->session->get('user');
            
            if (!is_array($userData)) {
                log_message('error', 'Dashboard: Invalid session user data structure');
                $this->session->destroy();
                return redirect()->to('login')
                    ->with('error', 'Session error. Please login again.');
            }

            // Prepare view data
            $data = [
                'title' => 'Dashboard',
                'username' => $userData['username'] ?? 'User',
                'email' => $userData['email'] ?? 'No email'
            ];

            return view('dashboard', $data);
            
        } catch (\Exception $e) {
            log_message('error', 'Dashboard error: ' . $e->getMessage());
            return redirect()->to('login')
                ->with('error', 'An error occurred. Please try again.');
        }
    }
}
